export const environment = {
  production: true,
  BACKEND_URL:'http://cltechapi.us-west-2.elasticbeanstalk.com/cltech/',
  ADMIN_URL:"/admin"
  //endPoint:http://cltech.hrms.s3-website-us-west-2.amazonaws.com/
};
