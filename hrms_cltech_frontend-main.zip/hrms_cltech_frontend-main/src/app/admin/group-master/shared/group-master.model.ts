export class GroupMaster{
  id!: number | null |undefined;
  groupName!: string | null|undefined;
  code!: string | null|undefined;
  value!: string | null|undefined;
  active: boolean|null|undefined;
    constructor(){};
}