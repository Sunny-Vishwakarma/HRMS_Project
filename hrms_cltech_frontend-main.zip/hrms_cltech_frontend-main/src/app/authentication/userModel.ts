export class UserModel{
    id!:number|null|undefined;
    name!:string|null|undefined;
    email!:string|null|undefined;
    username!:string|null|undefined
    password!:string|null|undefined;
    confirmPassword!:string|null|undefined;
    UserModel(){}
}